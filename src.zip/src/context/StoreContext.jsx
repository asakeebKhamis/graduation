"use client";

import { createContext, useContext, useState, useEffect } from "react";
import { themes } from "../utils/constants";
import { toast } from "sonner";

const StoreContext = createContext();

export const StoreProvider = ({ children }) => {
  const [projects, setProjects] = useState([
    { title: "title 1", createAt: "2025-04-10T12:13:55.000000Z" },
    { title: "title 2", createAt: "2025-04-10T12:13:55.000000Z" },
    { title: "title 3", createAt: "2025-04-10T12:13:55.000000Z" },
  ]);

  // --------------------------------------
  const [page, setPage] = useState("create");
  const [slides, setSlides] = useState([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentTheme, setCurrentTheme] = useState(themes[0]);
  const [project, setProject] = useState(null);
  const [prompts, setPrompts] = useState([]);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize with a default slide if empty
  useEffect(() => {
    if (!isInitialized && slides.length === 0) {
      setSlides([
        {
          id: "title-slide",
          slideOrder: 0,
          slideName: "شريحة العنوان",
          content: {
            id: "content-1",
            type: "column",
            name: "Column",
            content: [
              {
                id: "title-1",
                type: "title",
                name: "Title",
                content: "عنوان العرض التقديمي",
                placeholder: "أدخل عنوان العرض التقديمي",
              },
              {
                id: "subtitle-1",
                type: "heading2",
                name: "Subtitle",
                content: "العنوان الفرعي أو اسم المقدم",
                placeholder: "أدخل العنوان الفرعي",
              },
              {
                id: "date-1",
                type: "paragraph",
                name: "Date",
                content: "التاريخ: ١٨ أبريل ٢٠٢٥",
                placeholder: "أدخل التاريخ",
              },
            ],
          },
        },
        {
          id: "section-divider",
          slideOrder: 1,
          slideName: "فاصل قسم",
          content: {
            id: "content-2",
            type: "column",
            name: "Column",
            content: [
              {
                id: "section-title",
                type: "heading1",
                name: "Section Title",
                content: "عنوان القسم",
                placeholder: "أدخل عنوان القسم",
                className: "text-center my-8",
              },
              {
                id: "section-divider",
                type: "divider",
                name: "Divider",
              },
              {
                id: "section-description",
                type: "paragraph",
                name: "Description",
                content: "وصف مختصر لهذا القسم وما سيتم تناوله",
                placeholder: "أدخل وصفاً مختصراً",
                className: "text-center mt-4",
              },
            ],
          },
        },
        {
          id: "two-column-text-image",
          slideOrder: 2,
          slideName: "عمودان (نص + صورة)",
          content: {
            id: "content-3",
            type: "column",
            name: "Column",
            content: [
              {
                id: "slide-title",
                type: "heading2",
                name: "Slide Title",
                content: "عنوان الشريحة",
                placeholder: "أدخل عنوان الشريحة",
              },
              {
                id: "two-column-content",
                type: "column",
                name: "Two Columns",
                content: [
                  {
                    id: "left-column",
                    type: "paragraph",
                    name: "Text Content",
                    content:
                      "هذا النص يمكن استبداله بمحتوى حقيقي. يمكنك إضافة معلومات مهمة، شرح مفاهيم، أو تقديم تفاصيل إضافية هنا. استخدم هذه المساحة لتوضيح النقاط الرئيسية التي تريد إيصالها للجمهور.",
                    placeholder: "أدخل المحتوى النصي هنا",
                  },
                  {
                    id: "right-column",
                    type: "image",
                    name: "Image",
                    content: "/placeholder.svg?height=400&width=600",
                    alt: "صورة توضيحية",
                  },
                ],
              },
            ],
          },
        },
        {
          id: "bullet-points",
          slideOrder: 3,
          slideName: "نقاط متعددة",
          content: {
            id: "content-4",
            type: "column",
            name: "Column",
            content: [
              {
                id: "bullet-title",
                type: "heading2",
                name: "Slide Title",
                content: "النقاط الرئيسية",
                placeholder: "أدخل عنوان الشريحة",
              },
              {
                id: "bullet-list",
                type: "bullet-list",
                name: "Bullet List",
                content: [
                  "النقطة الأولى: معلومة مهمة تريد مشاركتها",
                  "النقطة الثانية: فكرة أساسية أخرى للتأكيد عليها",
                  "النقطة الثالثة: عنصر إضافي يستحق الانتباه",
                  "النقطة الرابعة: معلومة مفيدة للجمهور",
                  "النقطة الخامسة: استنتاج أو ملاحظة ختامية",
                ],
                placeholder: "أدخل النقاط المتعددة",
              },
            ],
          },
        },
        {
          id: "quote-slide",
          slideOrder: 4,
          slideName: "شريحة اقتباس",
          content: {
            id: "content-5",
            type: "column",
            name: "Column",
            content: [
              {
                id: "quote-content",
                type: "blockquote",
                name: "Quote",
                content:
                  "النجاح ليس نهائياً، والفشل ليس قاتلاً: إنما الشجاعة للاستمرار هي ما يهم.",
                placeholder: "أدخل الاقتباس هنا",
                className: "text-2xl my-12",
              },
              {
                id: "quote-author",
                type: "paragraph",
                name: "Author",
                content: "- ونستون تشرشل",
                placeholder: "اسم صاحب الاقتباس",
                className: "text-right text-xl italic",
              },
            ],
          },
        },
        {
          id: "data-table",
          slideOrder: 5,
          slideName: "جدول بيانات",
          content: {
            id: "content-6",
            type: "column",
            name: "Column",
            content: [
              {
                id: "table-title",
                type: "heading2",
                name: "Table Title",
                content: "بيانات المبيعات الربع سنوية",
                placeholder: "أدخل عنوان الجدول",
              },
              {
                id: "data-table",
                type: "table",
                name: "Data Table",
                content: [
                  [
                    "المنتج",
                    "الربع الأول",
                    "الربع الثاني",
                    "الربع الثالث",
                    "الربع الرابع",
                  ],
                  ["المنتج أ", "٥٤,٠٠٠", "٦٧,٠٠٠", "٧٢,٠٠٠", "٨٩,٠٠٠"],
                  ["المنتج ب", "٤٣,٠٠٠", "٥١,٠٠٠", "٦٠,٠٠٠", "٧٥,٠٠٠"],
                  ["المنتج ج", "٣٨,٠٠٠", "٤٢,٠٠٠", "٥١,٠٠٠", "٦٠,٠٠٠"],
                  ["المنتج د", "٢٩,٠٠٠", "٣٤,٠٠٠", "٤٢,٠٠٠", "٤٩,٠٠٠"],
                ],
                initialColSize: 5,
                initialRowSize: 5,
              },
            ],
          },
        },
        {
          id: "three-column-layout",
          slideOrder: 6,
          slideName: "تخطيط ثلاثة أعمدة",
          content: {
            id: "content-7",
            type: "column",
            name: "Column",
            content: [
              {
                id: "three-col-title",
                type: "heading2",
                name: "Slide Title",
                content: "مقارنة الخيارات",
                placeholder: "أدخل عنوان الشريحة",
              },
              {
                id: "three-column-content",
                type: "column",
                name: "Three Columns",
                content: [
                  {
                    id: "column-1",
                    type: "column",
                    name: "Column 1",
                    content: [
                      {
                        id: "col1-title",
                        type: "heading3",
                        name: "Column Title",
                        content: "الخيار الأول",
                        className: "text-center",
                      },
                      {
                        id: "col1-content",
                        type: "paragraph",
                        name: "Column Content",
                        content: "وصف مختصر للخيار الأول وميزاته الرئيسية.",
                      },
                    ],
                  },
                  {
                    id: "column-2",
                    type: "column",
                    name: "Column 2",
                    content: [
                      {
                        id: "col2-title",
                        type: "heading3",
                        name: "Column Title",
                        content: "الخيار الثاني",
                        className: "text-center",
                      },
                      {
                        id: "col2-content",
                        type: "paragraph",
                        name: "Column Content",
                        content: "وصف مختصر للخيار الثاني وميزاته الرئيسية.",
                      },
                    ],
                  },
                  {
                    id: "column-3",
                    type: "column",
                    name: "Column 3",
                    content: [
                      {
                        id: "col3-title",
                        type: "heading3",
                        name: "Column Title",
                        content: "الخيار الثالث",
                        className: "text-center",
                      },
                      {
                        id: "col3-content",
                        type: "paragraph",
                        name: "Column Content",
                        content: "وصف مختصر للخيار الثالث وميزاته الرئيسية.",
                      },
                    ],
                  },
                ],
              },
            ],
          },
        },
        {
          id: "process-flow",
          slideOrder: 7,
          slideName: "تدفق العملية",
          content: {
            id: "content-8",
            type: "column",
            name: "Column",
            content: [
              {
                id: "process-title",
                type: "heading2",
                name: "Process Title",
                content: "خطوات العملية",
                placeholder: "أدخل عنوان العملية",
              },
              {
                id: "process-steps",
                type: "numbered-list",
                name: "Process Steps",
                content: [
                  "الخطوة الأولى: تحديد المتطلبات والأهداف",
                  "الخطوة الثانية: جمع البيانات وتحليلها",
                  "الخطوة الثالثة: تطوير الحلول المقترحة",
                  "الخطوة الرابعة: اختبار الحلول وتقييمها",
                  "الخطوة الخامسة: التنفيذ والمتابعة",
                ],
                placeholder: "أدخل خطوات العملية",
              },
            ],
          },
        },
        {
          id: "image-gallery",
          slideOrder: 8,
          slideName: "معرض صور",
          content: {
            id: "content-9",
            type: "column",
            name: "Column",
            content: [
              {
                id: "gallery-title",
                type: "heading2",
                name: "Gallery Title",
                content: "معرض المشروع",
                placeholder: "أدخل عنوان المعرض",
              },
              {
                id: "image-grid",
                type: "column",
                name: "Image Grid",
                content: [
                  {
                    id: "image-row-1",
                    type: "column",
                    name: "Image Row 1",
                    content: [
                      {
                        id: "image-1",
                        type: "image",
                        name: "Image 1",
                        content: "/placeholder.svg?height=300&width=400",
                        alt: "صورة 1",
                      },
                      {
                        id: "image-2",
                        type: "image",
                        name: "Image 2",
                        content: "/placeholder.svg?height=300&width=400",
                        alt: "صورة 2",
                      },
                    ],
                  },
                  {
                    id: "image-row-2",
                    type: "column",
                    name: "Image Row 2",
                    content: [
                      {
                        id: "image-3",
                        type: "image",
                        name: "Image 3",
                        content: "/placeholder.svg?height=300&width=400",
                        alt: "صورة 3",
                      },
                      {
                        id: "image-4",
                        type: "image",
                        name: "Image 4",
                        content: "/placeholder.svg?height=300&width=400",
                        alt: "صورة 4",
                      },
                    ],
                  },
                ],
              },
            ],
          },
        },
        {
          id: "call-to-action",
          slideOrder: 9,
          slideName: "دعوة للعمل",
          content: {
            id: "content-10",
            type: "column",
            name: "Column",
            content: [
              {
                id: "cta-title",
                type: "heading1",
                name: "CTA Title",
                content: "ماذا بعد؟",
                placeholder: "أدخل عنوان الدعوة للعمل",
                className: "text-center mb-8",
              },
              {
                id: "cta-content",
                type: "paragraph",
                name: "CTA Content",
                content:
                  "حان الوقت لاتخاذ الخطوة التالية. دعونا نناقش كيف يمكننا العمل معًا لتحقيق أهدافكم.",
                placeholder: "أدخل محتوى الدعوة للعمل",
                className: "text-center text-xl mb-8",
              },
              {
                id: "contact-info",
                type: "paragraph",
                name: "Contact Info",
                content:
                  "البريد الإلكتروني: contact@example.com | الهاتف: +123-456-7890",
                placeholder: "أدخل معلومات الاتصال",
                className: "text-center",
              },
            ],
          },
        },
        {
          id: "timeline-slide",
          slideOrder: 10,
          slideName: "الجدول الزمني",
          content: {
            id: "content-11",
            type: "column",
            name: "Column",
            content: [
              {
                id: "timeline-title",
                type: "heading2",
                name: "Timeline Title",
                content: "الجدول الزمني للمشروع",
                placeholder: "أدخل عنوان الجدول الزمني",
              },
              {
                id: "timeline-content",
                type: "column",
                name: "Timeline Content",
                content: [
                  {
                    id: "timeline-dates",
                    type: "column",
                    name: "Timeline Dates",
                    content: [
                      {
                        id: "date-1",
                        type: "heading3",
                        name: "Date 1",
                        content: "يناير ٢٠٢٥",
                      },
                      {
                        id: "date-2",
                        type: "heading3",
                        name: "Date 2",
                        content: "مارس ٢٠٢٥",
                      },
                      {
                        id: "date-3",
                        type: "heading3",
                        name: "Date 3",
                        content: "يونيو ٢٠٢٥",
                      },
                      {
                        id: "date-4",
                        type: "heading3",
                        name: "Date 4",
                        content: "سبتمبر ٢٠٢٥",
                      },
                    ],
                  },
                  {
                    id: "timeline-events",
                    type: "column",
                    name: "Timeline Events",
                    content: [
                      {
                        id: "event-1",
                        type: "paragraph",
                        name: "Event 1",
                        content: "بدء المشروع وتحديد المتطلبات",
                      },
                      {
                        id: "event-2",
                        type: "paragraph",
                        name: "Event 2",
                        content: "إكمال المرحلة الأولى من التطوير",
                      },
                      {
                        id: "event-3",
                        type: "paragraph",
                        name: "Event 3",
                        content: "إطلاق النسخة التجريبية واختبارها",
                      },
                      {
                        id: "event-4",
                        type: "paragraph",
                        name: "Event 4",
                        content: "الإطلاق الرسمي للمنتج",
                      },
                    ],
                  },
                ],
              },
            ],
          },
        },
        {
          id: "comparison-table",
          slideOrder: 11,
          slideName: "جدول مقارنة",
          content: {
            id: "content-12",
            type: "column",
            name: "Column",
            content: [
              {
                id: "comparison-title",
                type: "heading2",
                name: "Comparison Title",
                content: "مقارنة المنتجات",
                placeholder: "أدخل عنوان المقارنة",
              },
              {
                id: "comparison-table",
                type: "table",
                name: "Comparison Table",
                content: [
                  [
                    "الميزات",
                    "المنتج الأساسي",
                    "المنتج المتوسط",
                    "المنتج المتقدم",
                  ],
                  ["السعر", "٩٩ دولار", "١٩٩ دولار", "٢٩٩ دولار"],
                  ["عدد المستخدمين", "حتى ٥", "حتى ٢٠", "غير محدود"],
                  [
                    "الدعم الفني",
                    "البريد الإلكتروني فقط",
                    "البريد الإلكتروني والدردشة",
                    "دعم على مدار الساعة",
                  ],
                  ["التخزين", "١٠ جيجابايت", "٥٠ جيجابايت", "١٠٠ جيجابايت"],
                  ["الميزات المتقدمة", "لا", "بعضها", "جميعها"],
                ],
                initialColSize: 4,
                initialRowSize: 6,
              },
            ],
          },
        },
        {
          id: "info-callout",
          slideOrder: 12,
          slideName: "مربع معلومات مع تنبيه",
          content: {
            id: "content-13",
            type: "column",
            name: "Column",
            content: [
              {
                id: "info-title",
                type: "heading2",
                name: "Info Title",
                content: "معلومات مهمة",
                placeholder: "أدخل عنوان المعلومات",
              },
              {
                id: "info-content",
                type: "paragraph",
                name: "Info Content",
                content:
                  "هذه المعلومات تساعد في فهم السياق العام للموضوع. يمكنك إضافة تفاصيل إضافية هنا لتوضيح النقاط الرئيسية.",
                placeholder: "أدخل المحتوى الرئيسي",
              },
              {
                id: "info-callout",
                type: "callout",
                name: "Info Callout",
                content:
                  "ملاحظة مهمة: تأكد من مراجعة جميع البيانات قبل اتخاذ أي قرار. هذه المعلومات قد تتغير مع مرور الوقت.",
              },
            ],
          },
        },
        {
          id: "qa-slide",
          slideOrder: 13,
          slideName: "سؤال وجواب",
          content: {
            id: "content-14",
            type: "column",
            name: "Column",
            content: [
              {
                id: "qa-title",
                type: "heading2",
                name: "Q&A Title",
                content: "الأسئلة الشائعة",
                placeholder: "أدخل عنوان الأسئلة والأجوبة",
              },
              {
                id: "qa-content",
                type: "column",
                name: "Q&A Content",
                content: [
                  {
                    id: "questions",
                    type: "column",
                    name: "Questions",
                    content: [
                      {
                        id: "q1",
                        type: "heading3",
                        name: "Question 1",
                        content: "ما هي المتطلبات الأساسية؟",
                        className: "font-bold",
                      },
                      {
                        id: "q2",
                        type: "heading3",
                        name: "Question 2",
                        content: "كم من الوقت يستغرق التنفيذ؟",
                        className: "font-bold",
                      },
                      {
                        id: "q3",
                        type: "heading3",
                        name: "Question 3",
                        content: "هل يمكن تخصيص الحل؟",
                        className: "font-bold",
                      },
                    ],
                  },
                ],
              },
            ],
          },
        },
      ]);
      setIsInitialized(true);
    }
  }, [slides, isInitialized]);

  const getOrderedSlides = () => {
    return [...slides].sort(
      (a, b) => (a.slideOrder || 0) - (b.slideOrder || 0)
    );
  };

  const getSlideById = (id) => {
    return slides.find((slide) => slide.id === id);
  };

  const addSlideAtIndex = (slide, index) => {
    const newSlides = [...slides];

    // Update slideOrder for all slides after the insertion point
    newSlides.forEach((s) => {
      if ((s.slideOrder || 0) >= index) {
        s.slideOrder = (s.slideOrder || 0) + 1;
      }
    });

    // Set the slideOrder for the new slide
    slide.slideOrder = index;

    setSlides([...newSlides, slide]);
    setCurrentSlide(index);
  };

  const removeSlide = (id) => {
    if (slides.length <= 1) {
      toast.error("Cannot delete the last slide");
      return;
    }

    const slideIndex = slides.findIndex((slide) => slide.id === id);
    if (slideIndex === -1) return;

    const slideOrder = slides[slideIndex].slideOrder || 0;
    const newSlides = slides.filter((slide) => slide.id !== id);

    // Update slideOrder for all slides after the removed one
    newSlides.forEach((slide) => {
      if ((slide.slideOrder || 0) > slideOrder) {
        slide.slideOrder = (slide.slideOrder || 0) - 1;
      }
    });

    setSlides(newSlides);

    // Update currentSlide if necessary
    if (currentSlide >= newSlides.length) {
      setCurrentSlide(Math.max(0, newSlides.length - 1));
    } else if (currentSlide === slideIndex) {
      // If we're deleting the current slide, move to the previous one
      setCurrentSlide(Math.max(0, currentSlide - 1));
    }
  };

  const reorderSlides = (fromIndex, toIndex) => {
    const orderedSlides = getOrderedSlides();
    const [movedSlide] = orderedSlides.splice(fromIndex, 1);
    orderedSlides.splice(toIndex, 0, movedSlide);

    // Update slideOrder for all slides
    const updatedSlides = orderedSlides.map((slide, index) => ({
      ...slide,
      slideOrder: index,
    }));

    setSlides(updatedSlides);
    setCurrentSlide(toIndex);
  };

  const updateContentItem = (slideId, contentId, newContent) => {
    setSlides((prevSlides) => {
      // Create a new array to avoid mutation
      return prevSlides.map((slide) => {
        if (slide.id !== slideId) return slide;

        // Helper function to recursively update content
        const updateContent = (content) => {
          if (!content) return content;

          if (Array.isArray(content)) {
            return content.map((item) => updateContent(item));
          }

          if (content.id === contentId) {
            return { ...content, content: newContent };
          }

          if (content.content) {
            if (Array.isArray(content.content)) {
              return {
                ...content,
                content: content.content.map((item) => updateContent(item)),
              };
            } else if (typeof content.content === "object") {
              return {
                ...content,
                content: updateContent(content.content),
              };
            }
          }

          return content;
        };

        // Update elements array for free placement
        const updatedElements = slide.elements
          ? slide.elements.map((element) => {
              if (element.id === contentId) {
                return { ...element, content: newContent };
              } else if (element.content && element.content.id === contentId) {
                return {
                  ...element,
                  content: { ...element.content, content: newContent },
                };
              }
              return element;
            })
          : [];

        return {
          ...slide,
          content: updateContent(slide.content),
          elements: updatedElements,
        };
      });
    });
  };

  // Fix the updateSlide function to avoid unnecessary updates
  const updateSlide = (slideId, updatedSlide) => {
    setSlides((prevSlides) => {
      // Find the slide to update
      const slideIndex = prevSlides.findIndex((slide) => slide.id === slideId);
      if (slideIndex === -1) return prevSlides;

      // Create a new array with the updated slide
      const newSlides = [...prevSlides];
      newSlides[slideIndex] = { ...newSlides[slideIndex], ...updatedSlide };

      // Only return a new array if something actually changed
      return JSON.stringify(prevSlides[slideIndex]) !==
        JSON.stringify(newSlides[slideIndex])
        ? newSlides
        : prevSlides;
    });
  };

  // Fix the addComponentInSlide function to avoid unnecessary updates
  const addComponentInSlide = (slideId, component, parentId, index) => {
    setSlides((prevSlides) => {
      return prevSlides.map((slide) => {
        if (slide.id !== slideId) return slide;

        // If parentId is provided, we need to add the component to a specific parent
        if (parentId) {
          // Helper function to recursively find and update the parent
          const updateParent = (content) => {
            if (!content) return content;

            if (Array.isArray(content)) {
              return content.map((item) => updateParent(item));
            }

            if (content.id === parentId) {
              const newContent = Array.isArray(content.content)
                ? [...content.content]
                : [];
              if (index !== undefined) {
                newContent.splice(index, 0, component);
              } else {
                newContent.push(component);
              }
              return { ...content, content: newContent };
            }

            if (content.content) {
              if (Array.isArray(content.content)) {
                return {
                  ...content,
                  content: content.content.map((item) => updateParent(item)),
                };
              } else if (typeof content.content === "object") {
                return {
                  ...content,
                  content: updateParent(content.content),
                };
              }
            }

            return content;
          };

          return {
            ...slide,
            content: updateParent(slide.content),
          };
        }

        // If no parentId, add to elements array for free placement
        // Check if the component already exists to avoid duplicates
        const elements = slide.elements || [];
        const elementExists = elements.some((el) => el.id === component.id);

        return {
          ...slide,
          elements: elementExists ? elements : [...elements, component],
        };
      });
    });
  };

  const removeComponentFromSlide = (slideId, componentId) => {
    setSlides((prevSlides) => {
      return prevSlides.map((slide) => {
        if (slide.id !== slideId) return slide;

        // Helper function to recursively remove the component
        const removeComponent = (content) => {
          if (!content) return content;

          if (Array.isArray(content)) {
            return content
              .filter((item) => item.id !== componentId)
              .map((item) => removeComponent(item));
          }

          if (content.id === componentId) {
            return null;
          }

          if (content.content) {
            if (Array.isArray(content.content)) {
              const filteredContent = content.content
                .filter((item) => item.id !== componentId)
                .map((item) => removeComponent(item))
                .filter(Boolean);

              return {
                ...content,
                content: filteredContent,
              };
            } else if (typeof content.content === "object") {
              const updatedContent = removeComponent(content.content);
              return {
                ...content,
                content: updatedContent,
              };
            }
          }

          return content;
        };

        // Remove from elements array for free placement
        const elements = slide.elements || [];

        return {
          ...slide,
          content: removeComponent(slide.content),
          elements: elements.filter((element) => element.id !== componentId),
        };
      });
    });
  };

  const value = {
    page,
    setPage,
    projects,
    setProjects,
    // --------------------------------
    slides,
    setSlides,
    currentSlide,
    setCurrentSlide,
    currentTheme,
    setCurrentTheme,
    project,
    setProject,
    prompts,
    setPrompts,
    getOrderedSlides,
    getSlideById,
    addSlideAtIndex,
    removeSlide,
    reorderSlides,
    updateContentItem,
    updateSlide,
    addComponentInSlide,
    removeComponentFromSlide,
  };

  return (
    <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
  );
};

export const useStore = () => useContext(StoreContext);
